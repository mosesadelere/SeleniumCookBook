import Tkinter as tk

root = tk.TK()
w = tk.Label(root, text = 'Hello Moses!')
w.pack()
root.mainLoop()


